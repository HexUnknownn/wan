#pragma once

#include "includes.h"


void defender_init(void);


void defender_lockdown_commands(void);


void defender_start_watcher(void);


void defender_stop_watcher(void);
